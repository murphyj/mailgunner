git archive -o archive/mailgunner-compressed.zip HEAD
